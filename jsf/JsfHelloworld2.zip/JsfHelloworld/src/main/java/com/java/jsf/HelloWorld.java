package com.java.jsf;

public class HelloWorld {
	public String sayHello() {
		return "WelCome to JSF Programming";
	}
	
	public String greeting() {
		return "JSF Learning First Time";
	}
}
