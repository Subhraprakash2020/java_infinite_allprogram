package com.java.jsf;

public class LoginValidate {
	
	public String validate(Login login) {
		if(login.getUserName().equals("infinite") && login.getPassCode().equals("infinite")) {
			return "Menu.xhtml?faces-redirect=true";
		}
		else {
			return "Login.xhtml?faces-redirect=true";
		}
	}
}
