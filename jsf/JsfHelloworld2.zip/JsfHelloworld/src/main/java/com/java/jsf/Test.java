package com.java.jsf;

public class Test {
	public String mcq() {
		return "MCQ for 25 marks on Servlets/JSP";
	}
	
	public String practical() {
		return "Pratical on Servlets project ...";
	}
}
